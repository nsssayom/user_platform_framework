create trigger set_expiry
  before INSERT
  on token
  for each row
  SET NEW.expiry_time = DATE_ADD(NOW(), INTERVAL 7 DAY);

