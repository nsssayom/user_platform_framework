create trigger update_expiry
  before UPDATE
  on token
  for each row
  SET NEW.expiry_time = DATE_ADD(NOW(), INTERVAL 7 DAY);

